package com.example.empleados.specification;

import com.example.empleados.modelo.EmpleadoEntity;
import org.springframework.data.jpa.domain.Specification;

public class EmpleadoSpecification {

	// Creamos las Specifications para el criteria del empleado

	// Specification por Nombre
	public static Specification<EmpleadoEntity> hasNombre(String nombre) {
		return (root, query, criteriaBuilder) -> criteriaBuilder.like(root.get("nombre"), "%" + nombre + "%");
	}

	// Specification por Puesto
	public static Specification<EmpleadoEntity> hasPuesto(String puesto) {
		return (root, query, criteriaBuilder) -> criteriaBuilder.equal(root.get("puesto"), puesto);
	}

	// Specification por Departamento
	public static Specification<EmpleadoEntity> hasDepartamentoId(Long departamentoId) {
		return (root, query, criteriaBuilder) -> criteriaBuilder.equal(root.get("departamento").get("id"),
				departamentoId);
	}
}