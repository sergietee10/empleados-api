package com.example.empleados.servicio;

import com.example.empleados.modelo.DepartamentoEntity;
import com.example.empleados.interfaces.DepartamentoInterface;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DepartamentoService {

	@Autowired
	private DepartamentoInterface departamentoInterface;

	// Guardar un departamento
	public DepartamentoEntity saveDepartamento(DepartamentoEntity departamento) {
		return departamentoInterface.save(departamento);
	}

	// Recuperamos todos los departamentos
	public List<DepartamentoEntity> findAllDepartamentos() {
		return departamentoInterface.findAll();
	}

	// Recuperamos un departamento por su id
	public Optional<DepartamentoEntity> findDepartamentoById(Long id) {
		return departamentoInterface.findById(id);
	}

	// Actualizamos un departamento
	public DepartamentoEntity updateDepartamento(Long id, DepartamentoEntity departamento) {
		if (departamentoInterface.existsById(id)) {
			departamento.setId(id);
			return departamentoInterface.save(departamento);
		} else {
			throw new RuntimeException("Departamento no encontrado");
		}
	}

	// Eliminamos un departamento
	public void deleteDepartamento(Long id) {
		if (departamentoInterface.existsById(id)) {
			departamentoInterface.deleteById(id);
		} else {
			throw new RuntimeException("Departamento no encontrado");
		}
	}
}