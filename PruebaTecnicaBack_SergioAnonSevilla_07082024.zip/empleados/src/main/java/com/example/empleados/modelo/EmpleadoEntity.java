package com.example.empleados.modelo;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Data
@NoArgsConstructor
public class EmpleadoEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotNull(message = "El nombre es obligatorio")
	@Size(max = 100, message = "El nombre no puede tener más de 100 caracteres")
	private String nombre;

	@NotNull(message = "El puesto es obligatorio")
	@Size(max = 50, message = "El puesto no puede tener más de 50 caracteres")
	private String puesto;

	@ManyToOne
	@JoinColumn(name = "departamento_id")
	@NotNull(message = "El departamento es obligatorio")
	private DepartamentoEntity departamento;

	// Getters y setters

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getPuesto() {
		return puesto;
	}

	public void setPuesto(String puesto) {
		this.puesto = puesto;
	}

	public DepartamentoEntity getDepartamento() {
		return departamento;
	}

	public void setDepartamento(DepartamentoEntity departamento) {
		this.departamento = departamento;
	}

}
