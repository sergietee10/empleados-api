package com.example.empleados.interfaces;

import com.example.empleados.modelo.EmpleadoEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmpleadoInterface extends JpaRepository<EmpleadoEntity, Long>, JpaSpecificationExecutor<EmpleadoEntity> {

    List<EmpleadoEntity> findByDepartamentoId(Long departamentoId);
	
}
