package com.example.empleados.controller;

import com.example.empleados.modelo.DepartamentoEntity;
import com.example.empleados.modelo.EmpleadoEntity;
import com.example.empleados.servicio.EmpleadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/departamentos/{departamentoId}/empleados")
public class EmpleadoController {

	// Importamos el servicio de Empleados
	@Autowired
	private EmpleadoService empleadoService;

	// Crear un empleado
	@PostMapping
	public EmpleadoEntity createEmpleado(@PathVariable Long departamentoId, @RequestBody EmpleadoEntity empleado) {
		DepartamentoEntity departamento = new DepartamentoEntity();
		departamento.setId(departamentoId);
		empleado.setDepartamento(departamento);
		return empleadoService.saveEmpleado(empleado);
	}

	// Get de todos los empleados
	@GetMapping
	public List<EmpleadoEntity> getAllEmpleados(@PathVariable Long departamentoId) {
		return empleadoService.findAllEmpleadosByDepartamentoId(departamentoId);
	}

	// Get de un empleado por su ID
	@GetMapping("/{empleadoId}")
	public ResponseEntity<EmpleadoEntity> getEmpleadoById(@PathVariable Long departamentoId,
			@PathVariable Long empleadoId) {
		Optional<EmpleadoEntity> empleado = empleadoService.findEmpleadoByIdAndDepartamentoId(empleadoId,
				departamentoId);
		return empleado.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	}

	// Eliminar un empleado
	@DeleteMapping("/{empleadoId}")
	public ResponseEntity<Void> deleteEmpleado(@PathVariable Long departamentoId, @PathVariable Long empleadoId) {
		if (empleadoService.findEmpleadoByIdAndDepartamentoId(empleadoId, departamentoId).isPresent()) {
			empleadoService.deleteEmpleado(empleadoId);
			return ResponseEntity.noContent().build();
		}
		return ResponseEntity.notFound().build();
	}

	// Actualizar un empleado
	@PutMapping("/{empleadoId}")
	public ResponseEntity<EmpleadoEntity> updateEmpleado(@PathVariable Long departamentoId,
			@PathVariable Long empleadoId, @RequestBody EmpleadoEntity empleadoDetails) {
		return empleadoService.findEmpleadoByIdAndDepartamentoId(empleadoId, departamentoId).map(empleado -> {
			empleado.setNombre(empleadoDetails.getNombre());
			empleado.setPuesto(empleadoDetails.getPuesto());
			EmpleadoEntity updatedEmpleado = empleadoService.updateEmpleado(empleadoId, empleado);
			return ResponseEntity.ok(updatedEmpleado);
		}).orElseGet(() -> ResponseEntity.notFound().build());
	}

	// Actualizar el departamento de un empleado
	@PutMapping("/{empleadoId}/departamento/{nuevoDepartamentoId}")
	public ResponseEntity<EmpleadoEntity> updateEmpleadoDepartamento(@PathVariable Long empleadoId,
			@PathVariable Long nuevoDepartamentoId) {
		try {
			EmpleadoEntity updatedEmpleado = empleadoService.updateEmpleadoDepartamento(empleadoId,
					nuevoDepartamentoId);
			return new ResponseEntity<>(updatedEmpleado, HttpStatus.OK);
		} catch (RuntimeException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	// Buscar por nombre, puesto o departamento con Specificactions
	@GetMapping("/buscar")
	public ResponseEntity<List<EmpleadoEntity>> searchEmpleados(@RequestParam(required = false) String nombre,
			@RequestParam(required = false) String puesto, @RequestParam(required = false) Long departamentoId) {
		List<EmpleadoEntity> empleados = empleadoService.findEmpleadosByCriteria(nombre, puesto, departamentoId);
		return ResponseEntity.ok(empleados);
	}

}