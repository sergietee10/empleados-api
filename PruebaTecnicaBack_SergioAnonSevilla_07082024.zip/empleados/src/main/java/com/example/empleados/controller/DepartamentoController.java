package com.example.empleados.controller;

import com.example.empleados.modelo.DepartamentoEntity;
import com.example.empleados.servicio.DepartamentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/departamentos")
public class DepartamentoController {

	// Importamos el servicio de Departamentos
	@Autowired
	private DepartamentoService departamentoService;

	// Crear un departamento
	@PostMapping
	public ResponseEntity<DepartamentoEntity> createDepartamento(@RequestBody DepartamentoEntity departamento) {
		DepartamentoEntity createdDepartamento = departamentoService.saveDepartamento(departamento);
		return new ResponseEntity<>(createdDepartamento, HttpStatus.CREATED);
	}

	// Get de todos los departamentos
	@GetMapping
	public ResponseEntity<List<DepartamentoEntity>> getAllDepartamentos() {
		List<DepartamentoEntity> departamentos = departamentoService.findAllDepartamentos();
		return new ResponseEntity<>(departamentos, HttpStatus.OK);
	}

	// Get de un departamento por su ID
	@GetMapping("/{id}")
	public ResponseEntity<DepartamentoEntity> getDepartamentoById(@PathVariable Long id) {
		Optional<DepartamentoEntity> departamento = departamentoService.findDepartamentoById(id);
		return departamento.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	}

	// Actualizar un departamento
	@PutMapping("/{id}")
	public ResponseEntity<DepartamentoEntity> updateDepartamento(@PathVariable Long id,
			@Valid @RequestBody DepartamentoEntity departamento) {
		try {
			DepartamentoEntity updatedDepartamento = departamentoService.updateDepartamento(id, departamento);
			return new ResponseEntity<>(updatedDepartamento, HttpStatus.OK);
		} catch (RuntimeException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	// Eliminar un departamento
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteDepartamento(@PathVariable Long id) {
		try {
			departamentoService.deleteDepartamento(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (RuntimeException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}
