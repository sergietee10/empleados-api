package com.example.empleados.interfaces;

import com.example.empleados.modelo.DepartamentoEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DepartamentoInterface extends JpaRepository<DepartamentoEntity, Long>{

}
