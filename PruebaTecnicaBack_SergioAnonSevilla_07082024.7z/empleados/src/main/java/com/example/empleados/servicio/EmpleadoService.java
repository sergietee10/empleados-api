package com.example.empleados.servicio;

import com.example.empleados.modelo.DepartamentoEntity;
import com.example.empleados.modelo.EmpleadoEntity;
import com.example.empleados.specification.EmpleadoSpecification;
import com.example.empleados.interfaces.DepartamentoInterface;
import com.example.empleados.interfaces.EmpleadoInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmpleadoService {

	@Autowired
	private EmpleadoInterface empleadoInterface;
	@Autowired
	private DepartamentoInterface departamentoInterface;

	// Guardar un empleado
	public EmpleadoEntity saveEmpleado(EmpleadoEntity empleado) {
		return empleadoInterface.save(empleado);
	}

	// Recuperamos un empleado por su id
	public Optional<EmpleadoEntity> findEmpleadoById(Long empleadoId) {
		return empleadoInterface.findById(empleadoId);
	}

	// Recuperamos todos los empleados
	public List<EmpleadoEntity> findAllEmpleadosByDepartamentoId(Long departamentoId) {
		return empleadoInterface.findByDepartamentoId(departamentoId);
	}

	// Recuperamos un empleado por departamento e id
	public Optional<EmpleadoEntity> findEmpleadoByIdAndDepartamentoId(Long id, Long departamentoId) {
		return empleadoInterface.findById(id)
				.filter(empleado -> empleado.getDepartamento().getId().equals(departamentoId));
	}

	// Eliminamos un empleado
	public void deleteEmpleado(Long id) {
		empleadoInterface.deleteById(id);
	}

	// Actualizamos un empleado
	public EmpleadoEntity updateEmpleado(Long empleadoId, EmpleadoEntity empleadoDet) {
		EmpleadoEntity empleado = empleadoInterface.findById(empleadoId)
				.orElseThrow(() -> new IllegalArgumentException("Empleado no encontrado"));
		empleado.setNombre(empleadoDet.getNombre());
		empleado.setPuesto(empleadoDet.getPuesto());
		return empleadoInterface.save(empleado);
	}

	// Actualizamos un departamento de un empleado
	public EmpleadoEntity updateEmpleadoDepartamento(Long empleadoId, Long nuevoDepartamentoId) {
		Optional<EmpleadoEntity> empleadoOptional = empleadoInterface.findById(empleadoId);
		Optional<DepartamentoEntity> departamentoOptional = departamentoInterface.findById(nuevoDepartamentoId);

		if (empleadoOptional.isPresent() && departamentoOptional.isPresent()) {
			EmpleadoEntity empleado = empleadoOptional.get();
			DepartamentoEntity nuevoDepartamento = departamentoOptional.get();
			empleado.setDepartamento(nuevoDepartamento);
			return empleadoInterface.save(empleado);
		} else {
			throw new RuntimeException("Empleado o Departamento no encontrado");
		}
	}

	// Recuperamos empleados segun lo que nos llegue en las Specifications
	public List<EmpleadoEntity> findEmpleadosByCriteria(String nombre, String puesto, Long departamentoId) {
		Specification<EmpleadoEntity> spec = Specification.where(null);

		if (nombre != null && !nombre.isEmpty()) {
			spec = spec.and(EmpleadoSpecification.hasNombre(nombre));
		}
		if (puesto != null && !puesto.isEmpty()) {
			spec = spec.and(EmpleadoSpecification.hasPuesto(puesto));
		}
		if (departamentoId != null) {
			spec = spec.and(EmpleadoSpecification.hasDepartamentoId(departamentoId));
		}

		return empleadoInterface.findAll(spec);
	}
}
